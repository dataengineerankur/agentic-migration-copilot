# Assumptions

- Mock mode used; replace with LLM provider for real mapping.
