# Validation Report

- Total DAGs parsed: 4
- Total tasks mapped: 12
- Unknown operator mappings: 0
- Assumptions recorded: 1
- Sources detected: None
- Sinks detected: delta, snowflake

## Follow-ups
- Review LLM mappings and confirm operator behavior.
- Validate schedules, retries, and SLA requirements.
